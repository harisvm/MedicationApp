package com.macom.medicationapp;

import android.widget.ArrayAdapter;

public class MedicineListAdapter extends ArrayAdapter<ItemListModel> {
}
